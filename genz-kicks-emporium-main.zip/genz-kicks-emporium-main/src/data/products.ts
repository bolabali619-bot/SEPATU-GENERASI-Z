import shoe1 from '@/assets/shoes/shoe-1.jpg';
import shoe2 from '@/assets/shoes/shoe-2.jpg';
import shoe3 from '@/assets/shoes/shoe-3.jpg';
import shoe4 from '@/assets/shoes/shoe-4.jpg';
import shoe5 from '@/assets/shoes/shoe-5.jpg';
import shoe6 from '@/assets/shoes/shoe-6.jpg';
import shoe7 from '@/assets/shoes/shoe-7.jpg';
import shoe8 from '@/assets/shoes/shoe-8.jpg';

export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: 'pria' | 'wanita' | 'unisex';
  rating: number;
  reviewCount: number;
  isPromo: boolean;
  description: string;
  sizes: number[];
  colors: string[];
  stock: number;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Air Max Classic White',
    brand: 'Nike',
    price: 1299000,
    originalPrice: 1599000,
    image: shoe1,
    category: 'unisex',
    rating: 4.8,
    reviewCount: 234,
    isPromo: true,
    description: 'Sepatu klasik dengan desain timeless dan kenyamanan maksimal untuk aktivitas sehari-hari.',
    sizes: [38, 39, 40, 41, 42, 43, 44],
    colors: ['Putih', 'Hitam', 'Abu-abu'],
    stock: 50
  },
  {
    id: '2',
    name: 'Runner Pro Black Orange',
    brand: 'Adidas',
    price: 1499000,
    image: shoe2,
    category: 'pria',
    rating: 4.9,
    reviewCount: 189,
    isPromo: false,
    description: 'Sepatu lari profesional dengan teknologi cushioning terbaik untuk performa maksimal.',
    sizes: [40, 41, 42, 43, 44, 45],
    colors: ['Hitam', 'Biru', 'Merah'],
    stock: 35
  },
  {
    id: '3',
    name: 'Retro Colorful Sneaker',
    brand: 'Puma',
    price: 899000,
    originalPrice: 1199000,
    image: shoe3,
    category: 'unisex',
    rating: 4.6,
    reviewCount: 156,
    isPromo: true,
    description: 'Sneaker bergaya retro dengan warna-warna cerah yang eye-catching untuk Gen Z.',
    sizes: [36, 37, 38, 39, 40, 41, 42],
    colors: ['Multi', 'Pink', 'Biru'],
    stock: 42
  },
  {
    id: '4',
    name: 'High-Top Pink Elegant',
    brand: 'Converse',
    price: 1099000,
    image: shoe4,
    category: 'wanita',
    rating: 4.7,
    reviewCount: 298,
    isPromo: false,
    description: 'High-top sneaker dengan warna pink pastel yang elegan dan feminin.',
    sizes: [35, 36, 37, 38, 39, 40],
    colors: ['Pink', 'Putih', 'Lavender'],
    stock: 28
  },
  {
    id: '5',
    name: 'Classic Leather Brown',
    brand: 'New Balance',
    price: 1799000,
    originalPrice: 2199000,
    image: shoe5,
    category: 'pria',
    rating: 4.9,
    reviewCount: 167,
    isPromo: true,
    description: 'Sepatu kulit premium dengan craftsmanship terbaik untuk tampilan sophisticated.',
    sizes: [40, 41, 42, 43, 44, 45],
    colors: ['Coklat', 'Hitam', 'Tan'],
    stock: 20
  },
  {
    id: '6',
    name: 'Chunky Platform White',
    brand: 'Fila',
    price: 1199000,
    image: shoe6,
    category: 'wanita',
    rating: 4.5,
    reviewCount: 203,
    isPromo: false,
    description: 'Platform sneaker chunky yang trendy untuk tampilan stylish dan edgy.',
    sizes: [35, 36, 37, 38, 39, 40],
    colors: ['Putih', 'Hitam', 'Pink'],
    stock: 45
  },
  {
    id: '7',
    name: 'Minimalist Black Edition',
    brand: 'Vans',
    price: 999000,
    originalPrice: 1299000,
    image: shoe7,
    category: 'unisex',
    rating: 4.8,
    reviewCount: 321,
    isPromo: true,
    description: 'Sneaker minimalis all-black yang versatile untuk berbagai occasion.',
    sizes: [36, 37, 38, 39, 40, 41, 42, 43, 44],
    colors: ['Hitam', 'Abu-abu'],
    stock: 60
  },
  {
    id: '8',
    name: 'Rainbow Gradient Vibes',
    brand: 'Nike',
    price: 1599000,
    image: shoe8,
    category: 'wanita',
    rating: 4.7,
    reviewCount: 178,
    isPromo: false,
    description: 'Sneaker dengan gradient warna pelangi yang vibrant dan playful.',
    sizes: [35, 36, 37, 38, 39, 40],
    colors: ['Multi', 'Pink', 'Biru'],
    stock: 30
  }
];

export const brands = ['Nike', 'Adidas', 'Puma', 'Converse', 'New Balance', 'Fila', 'Vans'];

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};
