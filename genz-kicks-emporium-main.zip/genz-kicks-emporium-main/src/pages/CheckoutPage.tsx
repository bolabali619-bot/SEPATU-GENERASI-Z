import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck, CheckCircle } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { useCart } from '@/context/CartContext';
import { formatPrice } from '@/data/products';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { items, getTotalPrice, clearCart } = useCart();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    notes: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmitOrder = async () => {
    if (!formData.name || !formData.email || !formData.phone || !formData.address || !formData.city) {
      toast.error('Mohon lengkapi semua data yang diperlukan');
      return;
    }

    setIsSubmitting(true);

    // Simulate sending order notification to email
    const orderDetails = {
      orderId: `ORD-${Date.now()}`,
      customer: formData,
      items: items.map(item => ({
        name: item.product.name,
        size: item.size,
        color: item.color,
        quantity: item.quantity,
        price: item.product.price
      })),
      total: getTotalPrice(),
      paymentMethod,
      orderDate: new Date().toLocaleString('id-ID')
    };

    console.log('Order submitted:', orderDetails);
    console.log('Email notification will be sent to: wkuku691@gmail.com');

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setIsSubmitting(false);
    setStep(3);
    clearCart();

    toast.success('Pesanan berhasil dibuat! Notifikasi telah dikirim ke email toko.');
  };

  if (items.length === 0 && step !== 3) {
    navigate('/keranjang');
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Steps */}
          <div className="flex items-center justify-center gap-4 mb-10">
            {[
              { num: 1, label: 'Data Diri' },
              { num: 2, label: 'Pembayaran' },
              { num: 3, label: 'Selesai' }
            ].map((s, i) => (
              <div key={s.num} className="flex items-center">
                <div
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors',
                    step >= s.num
                      ? 'bg-gradient-primary text-primary-foreground'
                      : 'bg-secondary text-muted-foreground'
                  )}
                >
                  {step > s.num ? <CheckCircle className="h-5 w-5" /> : s.num}
                </div>
                <span className={cn(
                  'ml-2 hidden sm:inline font-medium',
                  step >= s.num ? 'text-foreground' : 'text-muted-foreground'
                )}>
                  {s.label}
                </span>
                {i < 2 && (
                  <div className={cn(
                    'w-12 sm:w-20 h-1 mx-2 rounded',
                    step > s.num ? 'bg-gradient-primary' : 'bg-secondary'
                  )} />
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Customer Data */}
          {step === 1 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-card rounded-xl border border-border p-6">
                <h2 className="text-xl font-display font-semibold mb-6">Data Pengiriman</h2>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nama Lengkap *</Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Masukkan nama lengkap"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="email@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">No. Telepon *</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="08xxxxxxxxxx"
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Alamat Lengkap *</Label>
                    <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Jl. Contoh No. 123, RT/RW"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city">Kota *</Label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="Nama Kota"
                      />
                    </div>
                    <div>
                      <Label htmlFor="postalCode">Kode Pos</Label>
                      <Input
                        id="postalCode"
                        name="postalCode"
                        value={formData.postalCode}
                        onChange={handleInputChange}
                        placeholder="12345"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="notes">Catatan (opsional)</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      placeholder="Catatan untuk kurir..."
                      rows={2}
                    />
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-card rounded-xl border border-border p-6 h-fit">
                <h2 className="text-xl font-display font-semibold mb-4">Ringkasan Pesanan</h2>
                <div className="space-y-3 mb-6">
                  {items.map(item => (
                    <div key={`${item.product.id}-${item.size}`} className="flex gap-3">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.product.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.size} | {item.color} | x{item.quantity}
                        </p>
                        <p className="text-sm font-semibold text-gradient">
                          {formatPrice(item.product.price * item.quantity)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="border-t border-border pt-4 space-y-2">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal</span>
                    <span>{formatPrice(getTotalPrice())}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Ongkir</span>
                    <span className="text-primary">Gratis</span>
                  </div>
                  <div className="flex justify-between font-semibold text-lg pt-2 border-t border-border">
                    <span>Total</span>
                    <span className="text-gradient">{formatPrice(getTotalPrice())}</span>
                  </div>
                </div>
                <Button
                  variant="hero"
                  size="lg"
                  className="w-full mt-6"
                  onClick={() => setStep(2)}
                >
                  Lanjut ke Pembayaran
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Payment */}
          {step === 2 && (
            <div className="max-w-xl mx-auto">
              <div className="bg-card rounded-xl border border-border p-6">
                <h2 className="text-xl font-display font-semibold mb-6">Metode Pembayaran</h2>
                
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                  <div className={cn(
                    'flex items-center gap-4 p-4 rounded-xl border transition-colors cursor-pointer',
                    paymentMethod === 'cod' ? 'border-primary bg-primary/5' : 'border-border'
                  )}>
                    <RadioGroupItem value="cod" id="cod" />
                    <Label htmlFor="cod" className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <Truck className="h-6 w-6 text-primary" />
                        <div>
                          <p className="font-semibold">COD (Cash on Delivery)</p>
                          <p className="text-sm text-muted-foreground">Bayar saat barang sampai</p>
                        </div>
                      </div>
                    </Label>
                  </div>
                  
                  <div className={cn(
                    'flex items-center gap-4 p-4 rounded-xl border transition-colors cursor-pointer',
                    paymentMethod === 'transfer' ? 'border-primary bg-primary/5' : 'border-border'
                  )}>
                    <RadioGroupItem value="transfer" id="transfer" />
                    <Label htmlFor="transfer" className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <CreditCard className="h-6 w-6 text-primary" />
                        <div>
                          <p className="font-semibold">Transfer Bank</p>
                          <p className="text-sm text-muted-foreground">BCA / BNI / BRI / Mandiri</p>
                        </div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                {paymentMethod === 'transfer' && (
                  <div className="mt-6 p-4 bg-secondary/50 rounded-xl">
                    <p className="font-semibold mb-2">Detail Rekening:</p>
                    <p className="text-sm text-muted-foreground">Bank BCA</p>
                    <p className="text-lg font-mono font-bold">1234567890</p>
                    <p className="text-sm text-muted-foreground">a.n. SEPATU GEN Z</p>
                  </div>
                )}

                <div className="mt-6 p-4 bg-secondary/30 rounded-xl">
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total Pembayaran</span>
                    <span className="text-gradient">{formatPrice(getTotalPrice())}</span>
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Kembali
                  </Button>
                  <Button
                    variant="hero"
                    onClick={handleSubmitOrder}
                    disabled={isSubmitting}
                    className="flex-1"
                  >
                    {isSubmitting ? 'Memproses...' : 'Konfirmasi Pesanan'}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Success */}
          {step === 3 && (
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-12 w-12 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-display font-bold mb-4">
                Pesanan <span className="text-gradient">Berhasil!</span>
              </h1>
              <p className="text-muted-foreground max-w-md mx-auto mb-8">
                Terima kasih telah berbelanja di SEPATU GEN Z! 
                Notifikasi pesanan telah dikirim ke email toko.
                Kami akan segera memproses pesanan Anda.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="neon" onClick={() => navigate('/produk')}>
                  Lanjut Belanja
                </Button>
                <Button variant="outline" onClick={() => navigate('/riwayat')}>
                  Lihat Riwayat Pesanan
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default CheckoutPage;
