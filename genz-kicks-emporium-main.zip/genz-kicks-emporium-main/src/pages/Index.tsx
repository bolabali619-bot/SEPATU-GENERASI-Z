import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HeroSection from '@/components/HeroSection';
import FeaturedProducts from '@/components/FeaturedProducts';
import CategorySection from '@/components/CategorySection';
import PromoSection from '@/components/PromoSection';
import TestimonialSection from '@/components/TestimonialSection';
import BrandSection from '@/components/BrandSection';
import Chatbot from '@/components/Chatbot';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <BrandSection />
        <FeaturedProducts />
        <CategorySection />
        <PromoSection />
        <TestimonialSection />
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default Index;
