import { Package, Truck, CheckCircle, Clock } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatPrice } from '@/data/products';
import { cn } from '@/lib/utils';

// Sample order history data
const orders = [
  {
    id: 'ORD-1704123456789',
    date: '2024-01-15',
    status: 'delivered',
    items: [
      { name: 'Air Max Classic White', size: 42, quantity: 1, price: 1299000 }
    ],
    total: 1299000,
    tracking: [
      { status: 'Pesanan Dibuat', date: '15 Jan 2024, 10:00', completed: true },
      { status: 'Pembayaran Dikonfirmasi', date: '15 Jan 2024, 10:30', completed: true },
      { status: 'Sedang Dikemas', date: '15 Jan 2024, 14:00', completed: true },
      { status: 'Dalam Pengiriman', date: '16 Jan 2024, 09:00', completed: true },
      { status: 'Terkirim', date: '17 Jan 2024, 15:00', completed: true }
    ]
  },
  {
    id: 'ORD-1704234567890',
    date: '2024-01-20',
    status: 'shipping',
    items: [
      { name: 'Runner Pro Black Orange', size: 43, quantity: 1, price: 1499000 },
      { name: 'Minimalist Black Edition', size: 42, quantity: 1, price: 999000 }
    ],
    total: 2498000,
    tracking: [
      { status: 'Pesanan Dibuat', date: '20 Jan 2024, 14:00', completed: true },
      { status: 'Pembayaran Dikonfirmasi', date: '20 Jan 2024, 14:30', completed: true },
      { status: 'Sedang Dikemas', date: '20 Jan 2024, 16:00', completed: true },
      { status: 'Dalam Pengiriman', date: '21 Jan 2024, 08:00', completed: true },
      { status: 'Terkirim', date: '-', completed: false }
    ]
  },
  {
    id: 'ORD-1704345678901',
    date: '2024-01-25',
    status: 'processing',
    items: [
      { name: 'High-Top Pink Elegant', size: 38, quantity: 2, price: 1099000 }
    ],
    total: 2198000,
    tracking: [
      { status: 'Pesanan Dibuat', date: '25 Jan 2024, 09:00', completed: true },
      { status: 'Pembayaran Dikonfirmasi', date: '25 Jan 2024, 09:15', completed: true },
      { status: 'Sedang Dikemas', date: '-', completed: false },
      { status: 'Dalam Pengiriman', date: '-', completed: false },
      { status: 'Terkirim', date: '-', completed: false }
    ]
  }
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'delivered':
      return <Badge className="bg-green-500/20 text-green-600 border-0">Terkirim</Badge>;
    case 'shipping':
      return <Badge className="bg-blue-500/20 text-blue-600 border-0">Dalam Pengiriman</Badge>;
    case 'processing':
      return <Badge className="bg-yellow-500/20 text-yellow-600 border-0">Diproses</Badge>;
    default:
      return <Badge variant="secondary">Pending</Badge>;
  }
};

const OrderHistoryPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-8">
            Riwayat <span className="text-gradient">Pesanan</span>
          </h1>

          {orders.length === 0 ? (
            <div className="text-center py-16">
              <Package className="h-24 w-24 text-muted-foreground mx-auto mb-6" />
              <h2 className="text-xl font-semibold mb-2">Belum Ada Pesanan</h2>
              <p className="text-muted-foreground">Anda belum melakukan pemesanan apapun.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map(order => (
                <Card key={order.id}>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{order.id}</CardTitle>
                      <p className="text-sm text-muted-foreground">{order.date}</p>
                    </div>
                    {getStatusBadge(order.status)}
                  </CardHeader>
                  <CardContent>
                    {/* Order Items */}
                    <div className="mb-6">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between py-2 border-b border-border last:border-0">
                          <div>
                            <p className="font-medium">{item.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Ukuran: {item.size} | Qty: {item.quantity}
                            </p>
                          </div>
                          <span className="font-semibold">{formatPrice(item.price * item.quantity)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between pt-4 font-bold">
                        <span>Total</span>
                        <span className="text-gradient">{formatPrice(order.total)}</span>
                      </div>
                    </div>

                    {/* Tracking */}
                    <div>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <Truck className="h-5 w-5 text-primary" />
                        Tracking Pesanan
                      </h4>
                      <div className="space-y-4">
                        {order.tracking.map((track, idx) => (
                          <div key={idx} className="flex items-start gap-4">
                            <div className={cn(
                              'w-8 h-8 rounded-full flex items-center justify-center shrink-0',
                              track.completed ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'
                            )}>
                              {track.completed ? (
                                <CheckCircle className="h-4 w-4" />
                              ) : (
                                <Clock className="h-4 w-4" />
                              )}
                            </div>
                            <div className={cn(
                              'flex-1',
                              idx < order.tracking.length - 1 && 'border-l-2 border-dashed pb-4 -ml-4 pl-8',
                              track.completed ? 'border-primary' : 'border-secondary'
                            )}>
                              <p className={cn(
                                'font-medium',
                                !track.completed && 'text-muted-foreground'
                              )}>
                                {track.status}
                              </p>
                              <p className="text-sm text-muted-foreground">{track.date}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default OrderHistoryPage;
