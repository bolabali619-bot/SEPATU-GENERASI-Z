import { useState } from 'react';
import { Star, Send } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Testimonial {
  id: number;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

const TestimoniPage = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([
    {
      id: 1,
      name: 'Rizky Pratama',
      rating: 5,
      comment: 'Sepatu yang saya beli kualitasnya oke banget! Original 100% dan pengiriman cepat. Recommended seller!',
      date: '2 hari lalu'
    },
    {
      id: 2,
      name: 'Ayu Dewi',
      rating: 5,
      comment: 'Suka banget sama desainnya yang kekinian. Nyaman dipakai seharian, gak bikin pegel!',
      date: '1 minggu lalu'
    },
    {
      id: 3,
      name: 'Budi Santoso',
      rating: 4,
      comment: 'Harga bersahabat, kualitas premium. Pasti bakal repeat order lagi!',
      date: '2 minggu lalu'
    },
    {
      id: 4,
      name: 'Siti Nurhaliza',
      rating: 5,
      comment: 'Pengiriman cepat, packing rapi dan aman. Sepatunya original dan sesuai ekspektasi!',
      date: '3 minggu lalu'
    },
    {
      id: 5,
      name: 'Ahmad Fauzi',
      rating: 5,
      comment: 'Baru pertama kali beli di sini dan langsung puas! CS ramah dan responsif.',
      date: '1 bulan lalu'
    }
  ]);

  const [name, setName] = useState('');
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) {
      toast.error('Mohon lengkapi nama dan komentar');
      return;
    }

    const newTestimonial: Testimonial = {
      id: Date.now(),
      name: name.trim(),
      rating,
      comment: comment.trim(),
      date: 'Baru saja'
    };

    setTestimonials([newTestimonial, ...testimonials]);
    setName('');
    setComment('');
    setRating(5);
    toast.success('Terima kasih atas testimoni Anda!');
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
              Kata <span className="text-gradient">Mereka</span>
            </h1>
            <p className="text-muted-foreground">
              Testimoni dari pelanggan setia SEPATU GEN Z
            </p>
          </div>

          {/* Add Testimonial Form */}
          <Card className="mb-10 max-w-2xl mx-auto">
            <CardContent className="p-6">
              <h2 className="text-xl font-display font-semibold mb-4">Bagikan Pengalaman Anda</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  placeholder="Nama Anda"
                  value={name}
                  onChange={e => setName(e.target.value)}
                />
                
                {/* Rating */}
                <div>
                  <p className="text-sm font-medium mb-2">Rating</p>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(i => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setRating(i)}
                        onMouseEnter={() => setHoverRating(i)}
                        onMouseLeave={() => setHoverRating(0)}
                      >
                        <Star
                          className={cn(
                            'h-8 w-8 transition-colors',
                            i <= (hoverRating || rating)
                              ? 'fill-neon-orange text-neon-orange'
                              : 'text-muted'
                          )}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <Textarea
                  placeholder="Tulis pengalaman belanja Anda..."
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  rows={4}
                />

                <Button type="submit" variant="neon" className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Kirim Testimoni
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Testimonials Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map(testimonial => (
              <Card key={testimonial.id} className="hover:shadow-hover transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={cn(
                          'h-4 w-4',
                          i < testimonial.rating
                            ? 'fill-neon-orange text-neon-orange'
                            : 'text-muted'
                        )}
                      />
                    ))}
                  </div>
                  <p className="text-foreground mb-4">"{testimonial.comment}"</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{testimonial.name}</span>
                    <span className="text-sm text-muted-foreground">{testimonial.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default TestimoniPage;
