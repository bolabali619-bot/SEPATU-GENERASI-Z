import { useParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import Chatbot from '@/components/Chatbot';
import { products } from '@/data/products';

const CategoryPage = () => {
  const { category } = useParams<{ category: string }>();
  
  const filteredProducts = products.filter(p => {
    if (category === 'pria') return p.category === 'pria' || p.category === 'unisex';
    if (category === 'wanita') return p.category === 'wanita' || p.category === 'unisex';
    return true;
  });

  const title = category === 'pria' ? 'Sepatu Pria' : 'Sepatu Wanita';

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
              {title.split(' ')[0]} <span className="text-gradient">{title.split(' ')[1]}</span>
            </h1>
            <p className="text-muted-foreground">
              {filteredProducts.length} produk ditemukan
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default CategoryPage;
