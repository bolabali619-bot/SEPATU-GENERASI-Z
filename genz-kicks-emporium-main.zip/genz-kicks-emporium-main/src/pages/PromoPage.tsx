import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import Chatbot from '@/components/Chatbot';
import { products } from '@/data/products';

const PromoPage = () => {
  const promoProducts = products.filter(p => p.isPromo);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/20 mb-4">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-destructive"></span>
              </span>
              <span className="text-sm font-medium text-destructive">Limited Time Offer</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
              Promo <span className="text-gradient-hero">Spesial</span>
            </h1>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Jangan sampai kehabisan! Diskon hingga 30% untuk sepatu pilihan
            </p>
          </div>

          {/* Promo Banner */}
          <div className="mb-10 p-8 rounded-2xl bg-gradient-hero text-center">
            <h2 className="text-2xl md:text-3xl font-display font-bold text-white mb-2">
              DISKON HINGGA 30%
            </h2>
            <p className="text-white/80 mb-4">
              Gunakan kode: GENZ30 untuk diskon tambahan!
            </p>
          </div>

          {/* Products */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {promoProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default PromoPage;
