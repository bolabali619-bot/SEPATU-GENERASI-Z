import { MapPin, Phone, Mail, Clock, MessageCircle } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

const ContactPage = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Pesan Anda telah terkirim! Kami akan segera menghubungi Anda.');
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
              Hubungi <span className="text-gradient">Kami</span>
            </h1>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Ada pertanyaan? Kami siap membantu Anda. Hubungi kami melalui berbagai channel berikut.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <Card className="hover:shadow-hover transition-shadow">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Alamat Toko</h3>
                    <p className="text-muted-foreground">
                      Tuban Kota, Jawa Timur<br />
                      Indonesia
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-hover transition-shadow">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    <Phone className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">WhatsApp</h3>
                    <a 
                      href="https://wa.me/6285807412998" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline"
                    >
                      085807412998
                    </a>
                    <p className="text-sm text-muted-foreground mt-1">
                      Klik untuk chat langsung
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-hover transition-shadow">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Email</h3>
                    <a 
                      href="mailto:wkuku691@gmail.com"
                      className="text-primary hover:underline"
                    >
                      wkuku691@gmail.com
                    </a>
                    <p className="text-sm text-muted-foreground mt-1">
                      Untuk pertanyaan & konfirmasi pesanan
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-hover transition-shadow">
                <CardContent className="p-6 flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Jam Operasional</h3>
                    <p className="text-muted-foreground">
                      Senin - Sabtu: 08:00 - 21:00<br />
                      Minggu: 09:00 - 17:00
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* WhatsApp Button */}
              <a 
                href="https://wa.me/6285807412998?text=Halo,%20saya%20tertarik%20dengan%20produk%20SEPATU%20GEN%20Z" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block"
              >
                <Button variant="neon" size="lg" className="w-full">
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Chat via WhatsApp
                </Button>
              </a>
            </div>

            {/* Contact Form */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-display font-semibold mb-4">Kirim Pesan</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input placeholder="Nama Lengkap" required />
                    <Input type="email" placeholder="Email" required />
                  </div>
                  <Input placeholder="Subjek" required />
                  <Textarea placeholder="Tulis pesan Anda..." rows={6} required />
                  <Button type="submit" variant="hero" size="lg" className="w-full">
                    Kirim Pesan
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* About Section */}
          <div className="mt-16">
            <h2 className="text-2xl md:text-3xl font-display font-bold mb-6 text-center">
              Tentang <span className="text-gradient">SEPATU GEN Z</span>
            </h2>
            <div className="max-w-3xl mx-auto text-center">
              <p className="text-muted-foreground mb-4">
                SEPATU GEN Z adalah toko sepatu online terpercaya yang menyediakan berbagai macam sepatu original 
                dari brand-brand ternama seperti Nike, Adidas, Puma, Converse, dan lainnya.
              </p>
              <p className="text-muted-foreground mb-4">
                Kami berkomitmen untuk memberikan produk berkualitas dengan harga yang bersahabat, 
                pengiriman cepat, dan pelayanan yang ramah untuk Generasi Z seperti Anda.
              </p>
              <p className="text-muted-foreground">
                Express yourself with the best sneakers! 👟✨
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
};

export default ContactPage;
