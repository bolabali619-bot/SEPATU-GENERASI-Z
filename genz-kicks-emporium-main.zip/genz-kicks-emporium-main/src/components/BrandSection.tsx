import { brands } from '@/data/products';

const BrandSection = () => {
  return (
    <section className="py-12 border-y border-border/50 overflow-hidden">
      <div className="container mx-auto px-4">
        <p className="text-center text-muted-foreground mb-8">Brands yang kami jual</p>
        <div className="flex items-center justify-center gap-8 md:gap-16 flex-wrap">
          {brands.map((brand, index) => (
            <div
              key={index}
              className="text-2xl md:text-3xl font-display font-bold text-muted-foreground/50 hover:text-primary transition-colors cursor-pointer"
            >
              {brand}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandSection;
