import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Truck, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroBanner from '@/assets/hero-banner.jpg';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroBanner}
          alt="Hero Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10 pt-20">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 animate-fade-in">
            <Zap className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">New Collection 2024</span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold mb-6 animate-slide-up">
            Temukan{' '}
            <span className="text-gradient-hero">Style</span>
            <br />
            Generasi Z-mu
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-lg animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Koleksi sepatu terlengkap dengan desain yang kekinian dan harga yang bersahabat. Express yourself!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Link to="/produk">
              <Button variant="hero" size="xl">
                Belanja Sekarang
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </Link>
            <Link to="/promo">
              <Button variant="glass" size="xl">
                Lihat Promo
              </Button>
            </Link>
          </div>

          {/* Features */}
          <div className="grid grid-cols-3 gap-4 md:gap-8 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="p-2 md:p-3 rounded-xl bg-primary/10">
                <Truck className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm md:text-base">Gratis Ongkir</p>
                <p className="text-xs text-muted-foreground hidden md:block">Min. 500k</p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="p-2 md:p-3 rounded-xl bg-primary/10">
                <Shield className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm md:text-base">Original</p>
                <p className="text-xs text-muted-foreground hidden md:block">100% Asli</p>
              </div>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <div className="p-2 md:p-3 rounded-xl bg-primary/10">
                <Zap className="h-5 w-5 md:h-6 md:w-6 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm md:text-base">Fast Response</p>
                <p className="text-xs text-muted-foreground hidden md:block">24/7</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Animated Gradient Orbs */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-neon-purple/20 rounded-full blur-3xl animate-pulse-slow pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/3 w-64 h-64 bg-neon-cyan/20 rounded-full blur-3xl animate-pulse-slow pointer-events-none" style={{ animationDelay: '1s' }} />
    </section>
  );
};

export default HeroSection;
