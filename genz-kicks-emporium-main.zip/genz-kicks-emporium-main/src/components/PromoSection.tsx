import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard';
import { products } from '@/data/products';

const PromoSection = () => {
  const promoProducts = products.filter(p => p.isPromo).slice(0, 4);

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-background via-secondary/30 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-destructive/10 border border-destructive/20 mb-4">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-destructive"></span>
            </span>
            <span className="text-sm font-medium text-destructive">Limited Time Offer</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Promo <span className="text-gradient-hero">Spesial</span>
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Jangan sampai kehabisan! Diskon hingga 30% untuk sepatu pilihan
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {promoProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center">
          <Link to="/promo">
            <Button variant="hero" size="lg">
              Lihat Semua Promo
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PromoSection;
