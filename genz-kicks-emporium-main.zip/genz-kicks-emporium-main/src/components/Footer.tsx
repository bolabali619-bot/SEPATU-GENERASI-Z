import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Instagram, Facebook, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-2xl font-display font-bold text-gradient mb-4">
              SEPATU GEN Z
            </h3>
            <p className="text-muted-foreground mb-4">
              Toko sepatu terlengkap untuk generasi Z. Temukan style-mu disini!
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Menu</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/produk" className="text-muted-foreground hover:text-primary transition-colors">
                  Semua Produk
                </Link>
              </li>
              <li>
                <Link to="/kategori/pria" className="text-muted-foreground hover:text-primary transition-colors">
                  Sepatu Pria
                </Link>
              </li>
              <li>
                <Link to="/kategori/wanita" className="text-muted-foreground hover:text-primary transition-colors">
                  Sepatu Wanita
                </Link>
              </li>
              <li>
                <Link to="/promo" className="text-muted-foreground hover:text-primary transition-colors">
                  Promo
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-display font-semibold mb-4">Layanan</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/testimoni" className="text-muted-foreground hover:text-primary transition-colors">
                  Testimoni
                </Link>
              </li>
              <li>
                <Link to="/riwayat" className="text-muted-foreground hover:text-primary transition-colors">
                  Riwayat Pesanan
                </Link>
              </li>
              <li>
                <Link to="/kontak" className="text-muted-foreground hover:text-primary transition-colors">
                  Hubungi Kami
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold mb-4">Kontak</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-muted-foreground">Tuban Kota, Jawa Timur</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary shrink-0" />
                <a 
                  href="https://wa.me/6285807412998" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  085807412998
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary shrink-0" />
                <a 
                  href="mailto:wkuku691@gmail.com"
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  wkuku691@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} SEPATU GEN Z. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
