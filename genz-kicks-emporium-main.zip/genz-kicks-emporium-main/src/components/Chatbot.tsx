import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const botResponses: { [key: string]: string } = {
  halo: 'Halo! Selamat datang di SEPATU GEN Z 👋 Ada yang bisa saya bantu?',
  hai: 'Hai! Selamat datang di SEPATU GEN Z 👋 Ada yang bisa saya bantu?',
  produk: 'Kami menyediakan berbagai macam sepatu dari brand ternama seperti Nike, Adidas, Puma, Converse, dan lainnya. Silakan cek menu "Semua Produk" untuk melihat koleksi lengkap kami! 👟',
  harga: 'Harga sepatu kami mulai dari Rp 899.000 - Rp 1.999.000. Kami juga sering ada promo menarik lho! Cek menu "Promo" untuk info lebih lanjut 🏷️',
  promo: 'Saat ini kami sedang ada promo diskon hingga 30%! Cek menu "Promo" untuk melihat produk-produk diskon kami 🔥',
  ongkir: 'Gratis ongkir untuk pembelian minimal Rp 500.000! Pengiriman ke seluruh Indonesia 📦',
  bayar: 'Kami menerima pembayaran via Transfer Bank dan COD (Cash on Delivery). Pilih yang paling nyaman untuk kamu! 💳',
  pembayaran: 'Kami menerima pembayaran via Transfer Bank dan COD (Cash on Delivery). Pilih yang paling nyaman untuk kamu! 💳',
  cod: 'Ya, kami melayani COD (Cash on Delivery)! Bayar saat barang sampai di tangan kamu 🚚',
  transfer: 'Untuk transfer bank, kami menerima BCA, BNI, BRI, dan Mandiri. Detail rekening akan diberikan saat checkout 🏦',
  ukuran: 'Ukuran sepatu yang tersedia mulai dari 35-45 (tergantung model). Detail ukuran ada di halaman produk masing-masing 📏',
  size: 'Ukuran sepatu yang tersedia mulai dari 35-45 (tergantung model). Detail ukuran ada di halaman produk masing-masing 📏',
  kontak: 'Hubungi kami di WhatsApp: 085807412998 atau email: wkuku691@gmail.com. Kami berlokasi di Tuban Kota 📍',
  alamat: 'Toko kami berlokasi di Tuban Kota, Jawa Timur. Untuk pembelian online, silakan order melalui website ini 🏪',
  retur: 'Barang bisa diretur dalam 7 hari jika ada cacat produksi. Pastikan barang belum dipakai dan masih ada tag-nya ya! ✅',
  original: 'Semua produk kami 100% ORIGINAL dengan garansi resmi. No KW-KW club! 💯',
  asli: 'Semua produk kami 100% ORIGINAL dengan garansi resmi. No KW-KW club! 💯',
};

const getResponse = (message: string): string => {
  const lowerMessage = message.toLowerCase();
  for (const [key, response] of Object.entries(botResponses)) {
    if (lowerMessage.includes(key)) {
      return response;
    }
  }
  return 'Maaf, saya kurang mengerti pertanyaanmu 😅 Coba tanyakan tentang: produk, harga, promo, pembayaran, ongkir, ukuran, atau kontak kami. Atau hubungi CS kami di WhatsApp: 085807412998 📱';
};

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Halo! Selamat datang di SEPATU GEN Z 👟 Saya adalah asisten virtual yang siap membantu kamu. Silakan tanyakan tentang produk, harga, promo, atau lainnya!',
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate typing delay
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: getResponse(inputValue),
        isBot: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          'fixed bottom-6 right-6 z-50 p-4 rounded-full shadow-neon transition-all duration-300 hover:scale-110',
          isOpen ? 'bg-destructive' : 'bg-gradient-primary'
        )}
      >
        {isOpen ? (
          <X className="h-6 w-6 text-primary-foreground" />
        ) : (
          <MessageCircle className="h-6 w-6 text-primary-foreground" />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-80 md:w-96 bg-card rounded-2xl shadow-hover border border-border overflow-hidden animate-scale-in">
          {/* Header */}
          <div className="bg-gradient-primary p-4">
            <h3 className="font-display font-bold text-primary-foreground">Chat dengan Kami</h3>
            <p className="text-sm text-primary-foreground/80">Biasanya membalas dalam beberapa menit</p>
          </div>

          {/* Messages */}
          <ScrollArea className="h-80 p-4">
            <div className="space-y-4">
              {messages.map(message => (
                <div
                  key={message.id}
                  className={cn(
                    'flex',
                    message.isBot ? 'justify-start' : 'justify-end'
                  )}
                >
                  <div
                    className={cn(
                      'max-w-[80%] p-3 rounded-2xl text-sm',
                      message.isBot
                        ? 'bg-secondary text-secondary-foreground rounded-bl-none'
                        : 'bg-gradient-primary text-primary-foreground rounded-br-none'
                    )}
                  >
                    {message.text}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Input */}
          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <Input
                placeholder="Ketik pesan..."
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1"
              />
              <Button variant="neon" size="icon" onClick={handleSend}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
