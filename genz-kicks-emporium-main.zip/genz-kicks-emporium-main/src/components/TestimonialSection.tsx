import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const testimonials = [
  {
    id: 1,
    name: 'Rizky Pratama',
    rating: 5,
    comment: 'Sepatu yang saya beli kualitasnya oke banget! Original 100% dan pengiriman cepat. Recommended seller!',
    date: '2 hari lalu'
  },
  {
    id: 2,
    name: 'Ayu Dewi',
    rating: 5,
    comment: 'Suka banget sama desainnya yang kekinian. Nyaman dipakai seharian, gak bikin pegel!',
    date: '1 minggu lalu'
  },
  {
    id: 3,
    name: 'Budi Santoso',
    rating: 4,
    comment: 'Harga bersahabat, kualitas premium. Pasti bakal repeat order lagi!',
    date: '2 minggu lalu'
  }
];

const TestimonialSection = () => {
  return (
    <section className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Kata <span className="text-gradient">Mereka</span>
          </h2>
          <p className="text-muted-foreground">
            Testimoni dari pelanggan setia SEPATU GEN Z
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map(testimonial => (
            <Card key={testimonial.id} className="bg-card hover:shadow-hover transition-shadow duration-300">
              <CardContent className="p-6">
                <Quote className="h-8 w-8 text-primary/20 mb-4" />
                <p className="text-foreground mb-4">{testimonial.comment}</p>
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < testimonial.rating
                          ? 'fill-neon-orange text-neon-orange'
                          : 'text-muted'
                      }`}
                    />
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{testimonial.name}</span>
                  <span className="text-sm text-muted-foreground">{testimonial.date}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
