import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import shoe4 from '@/assets/shoes/shoe-4.jpg';
import shoe2 from '@/assets/shoes/shoe-2.jpg';

const CategorySection = () => {
  const categories = [
    {
      title: 'Sepatu Pria',
      description: 'Koleksi lengkap untuk pria modern',
      image: shoe2,
      link: '/kategori/pria',
      gradient: 'from-blue-600/80 to-cyan-500/80'
    },
    {
      title: 'Sepatu Wanita',
      description: 'Style feminin yang memikat',
      image: shoe4,
      link: '/kategori/wanita',
      gradient: 'from-pink-500/80 to-rose-400/80'
    }
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-2">
            Kategori <span className="text-gradient">Pilihan</span>
          </h2>
          <p className="text-muted-foreground">
            Temukan sepatu sesuai dengan gaya kamu
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map((category, index) => (
            <Link
              key={index}
              to={category.link}
              className="group relative h-64 md:h-80 rounded-2xl overflow-hidden"
            >
              <img
                src={category.image}
                alt={category.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className={`absolute inset-0 bg-gradient-to-t ${category.gradient}`} />
              <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-end">
                <h3 className="text-2xl md:text-3xl font-display font-bold text-white mb-2">
                  {category.title}
                </h3>
                <p className="text-white/80 mb-4">{category.description}</p>
                <div className="flex items-center gap-2 text-white font-medium group-hover:gap-4 transition-all">
                  <span>Lihat Koleksi</span>
                  <ArrowRight className="h-5 w-5" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
